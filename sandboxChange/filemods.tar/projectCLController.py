#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Rafal GRZYMKOWSKI 2013-11
# Radek LUDACKA 2013-11

from __future__ import absolute_import
from __future__ import print_function

from BelleDIRAC.Client.helpers.auth import userCreds, getProxyUser, \
    getProxyUserIfNotWasDefined
from BelleDIRAC.Client.helpers.terminalDisplay import renderTable, \
    generateTwoKindItemsTable, renderOutput, putBar, clearBar
from BelleDIRAC.Client.helpers.utils import gb2Error
from BelleDIRAC.gbasf2.lib.job.information_collector import InformationCollector
from BelleDIRAC.gbasf2.lib.job.manager import Manager
try:
    import BelleDIRAC.gbasf2.lib.gbasf2 as gbasf2
except AttributeError:
    import gbasf2
import BelleDIRAC.gbasf2.lib.gb2_job_test as gb2_job_test
from six.moves import range
from six.moves import zip


# RL: if is Dirac defined in global environment then
# proxy has not Belle VOMS extensions error happens
# from DIRAC.Interfaces.API.Dirac import Dirac
# dirac = Dirac()

@userCreds
def projectSummary(args=None):
    user = args.user
    group = args.group
    date = args.date

    condDict = {}
    if not user:
        condDict['Owner'] = getProxyUser()
    elif user.lower() != 'all':
        condDict['Owner'] = user

    if group:
        condDict['OwnerGroup'] = group

    tableData = [[
        'Project',
        'Owner',
        'Status',
        'Done',
        'Fail',
        'Run',
        'Wait',
        'Submission Time(UTC)',
        'Duration',
    ]]

    keys = [
        'proj_Name',
        'Owner',
        'status',
        'terminal_ok',
        'terminal_bad',
        'nonterminal',
        'waiting',
        'SubmissionTime',
        'Duration',
    ]

    if args.long:
        tableData = [[
            'Project',
            'Owner',
            'Status',
            'Done',
            'Comp',
            'Fail',
            'Run',
            'Wait',
            'Submission Time(UTC)',
            'LastUpdate Time(UTC)',
            'Duration',
        ]]
        keys = [
            'proj_Name',
            'Owner',
            'status',
            'done',
            'completed',
            'terminal_bad',
            'nonterminal',
            'waiting',
            'SubmissionTime',
            'LastUpdateTime',
            'Duration',
        ]

    infoCollector = InformationCollector()

    if args.project:
        jobGroupResult = {'OK': 'True', 'Value': []}
        for proj in args.project:
            condDict['JobGroup'] = proj
            _jobGroupResult = infoCollector.getJobGroups(condDict, date)
            if not _jobGroupResult['OK']:
                gb2Error(_jobGroupResult)
            jobGroupResult['Value'].extend(_jobGroupResult['Value'])
    else:
        jobGroupResult = infoCollector.getJobGroups(condDict, date)
        if not jobGroupResult['OK']:
            gb2Error(jobGroupResult)
    data = {'numRecords': len(jobGroupResult['Value']), 'projects': []}
    for i, record in enumerate(jobGroupResult['Value']):
        if user and user.lower() == 'all' and args.project:
            owners = infoCollector.getJobOwners({'JobGroup': record}, date)
            if not len(owners):
                return ''
            for owner in owners:
                _condDict=condDict
                _condDict['JobGroup'] = record
                _condDict['Owner'] = owner
                rD, srD = infoCollector.createRecordData(_condDict, args.showAll, isScout=args.scout)
                if rD:
                    data['projects'].append(rD)
                if args.scout and srD:
                    data['projects'].append(srD)
        else:
            _condDict=condDict
            _condDict['JobGroup'] = record
            rD, srD = infoCollector.createRecordData(_condDict, args.showAll, isScout=args.scout)
            if rD:
                data['projects'].append(rD)
            if args.scout and srD:
                data['projects'].append(srD)

        if not args.noBar:
            jobGroubLen = len(jobGroupResult['Value'])
            fraction = float(i) / float(jobGroubLen)
            putBar(int(fraction * 100), 25)

    if not args.noBar:
        clearBar(25)
    for project in sorted(data['projects'], lambda x, y: cmp(x['SubmissionTime'
                                                               ], y['SubmissionTime'])):
        record = [project[key] for key in keys]
        tableData.append(record)
    return renderTable(tableData)


@userCreds
def delete(args=None):
    return doOperation(args, Manager().delete, 'deleted', 'delete')


@userCreds
def kill(args=None):
    return doOperation(args, Manager().kill, 'killed', 'kill')


def doOperation(
    args,
    operation,
    operationNamePast,
    operationName,
):

    user = getProxyUserIfNotWasDefined(args.user)
    group = args.group
    date = args.date
    projects = args.project
    jobs = args.jobid

    if not args.force:
        from utils.ui import UI
        if jobs:
            result = UI().yes_no_dialog('Do you want %s %s job(s)'
                                        % (operationName, jobs))
        else:
            result = UI().yes_no_dialog('Do you want %s %s project(s)'
                                        % (operationName, projects))
        if not result['OK'] or not result['Value']:
            return ''

    result = operation(jobs, projects, [user, group], date)

    head = ['Job', 'result']
    data = generateTwoKindItemsTable(result['Value'], '%s jobs:'
                                     % operationNamePast, 'Not %s jobs:'
                                     % operationNamePast, head)
    return renderTable(data)


@userCreds
def status(args=None):
    infoCollector = InformationCollector()

    if args.jobid:
        projectItems = args.jobid
    else:
        projects = args.project
        login = [args.user, args.group]
        statuses = {'Status': [args.status],
                    'MinorStatus': [args.minorstatus],
                    'ApplicationStatus': [args.appstatus]}

        result = infoCollector.getAllJobsInProjects(projects, args.date,
                                                    login, statuses, args.site)

        projectItems = [jobs for project in projects for jobs in result['Value'][project]]
        if len(projectItems) == 0:
            return ''

    firstJobID = projectItems[0]
    result = infoCollector.getJobParameters(projectItems, ['ScoutID'])
    scoutItemsSet = set()
    if result['OK']:
        if result['Value']:
            for jid in result['Value']:
                scoutID = result['Value'][jid]['ScoutID']
                ids = scoutID.split(':')
                for i in range(int(ids[0]), int(ids[1]) + 1):
                    scoutItemsSet.add(str(i))
    else:
        print(result['Message'])

    scoutItems = list(scoutItemsSet)
    totalItems = projectItems + scoutItems
    totalItems = list(set(totalItems))
    totalItems.sort()
    nsjobs = len(scoutItems)
    njobs = len(totalItems) - len(scoutItems)
    msg = ''
    if njobs == 1:
        msg = '%d job' % njobs
    else:
        msg = '%d jobs' % njobs
    if scoutItems:
        msg += ' and %d scout jobs' % nsjobs
    if (njobs > 1 or nsjobs > 0):
        msg += ' are selected.\n'
        print(msg)

    status = infoCollector.getJobSummary(totalItems)
    if args.long:
        jobIDs = [int(j) for j in totalItems]
        ret = infoCollector.resolveMultiple(jobIDs)
        if not ret['OK']:
            return ret
        siteDict = ret['Value']

        for jobId in totalItems:
            if not ret['OK']:
                return ret
            site = ','.join(siteDict[int(jobId)])
            status['Value'][int(jobId)]['Site'] = site

    counts = {'Waiting': 0, 'Scouting': 0, 'Running': 0, 'Done': 0, 'Completed': 0, 'Stalled': 0, 'Failed': 0, 'Killed': 0, 'Deleted': 0}
    import copy
    scounts = copy.copy(counts)

    data = [['Job id', 'Status', 'MinorStatus', 'ApplicationStatus', 'Site']]

    if args.long:
        data = [['Job id',
                 'Status',
                 'LastUpdateTime',
                 'MinorStatus',
                 'Site',
                 'HeartBeatTime',
                 'ApplicationStatus',
                 'JobGroup',
                 'Owner',
                 'SubmissionTime']]

    for jobId in totalItems:
        if jobId in scoutItems:
            msgjobID = "%d (scout)" % int(jobId)
        else:
            msgjobID = int(jobId)

        record = [
            msgjobID,
            status['Value'][int(jobId)]['Status'],
            status['Value'][int(jobId)]['MinorStatus'],
            status['Value'][int(jobId)]['ApplicationStatus'],
            status['Value'][int(jobId)]['Site']]

        if args.long:
            record = [msgjobID]
            record += list(status['Value'][int(jobId)].values())

        for i in list(counts.keys()):
            if jobId in scoutItems:
                scounts[i] += status['Value'][int(jobId)]['Status'].count(i)
            else:
                counts[i] += status['Value'][int(jobId)]['Status'].count(i)
        data.append(record)
    width = 150
    if args.long:
        width = 250
    print(renderTable(data, width))

    if scoutItems:
        print('\n--- Summary of Selected Jobs (number for scout jobs) ---')
    else:
        print('\n--- Summary of Selected Jobs ---')

    msgSummary = ''
    for i in sorted(counts.keys()):
        msgSummary += '%s:%s' % (i, counts[i])
        if scounts[i]:
            msgSummary += ' (%s)' % scounts[i]
        msgSummary += '  '

    print(msgSummary)
    return ''


@userCreds
def output(args=None):

    projects = args.project
    jobs = args.jobid

    manager = Manager()
    if projects:
        print('download output sandbox below ./log/PROJECT/JOBID')
        print('%s project are selected.' % len(projects))
        print('Please wait...')

        statuses = {'Status': [args.status],
                    'MinorStatus': [args.minorstatus],
                    'ApplicationStatus': [args.appstatus]}

        login = [args.user, args.group]
        result = manager.downloadProjectsOutput(projects, args.date, login,
                                                statuses)

        for (project, jobs) in result['Value'].items():
            head = 'downloaded project: %s' % project
            print(renderTable(renderOutput(head, jobs)))
        return ''

    if jobs:
        print('download output sandbox below ./log/JOBID')
        print('%d jobs are selected.' % len(jobs))
        print('Please wait...')
        logDir = 'log'
        import os
        try:
            os.makedirs(logDir)
        except OSError:
            pass
        os.chdir(logDir)
        result = manager.downloadJobsOutput(jobs)
        head = 'Result for jobs: %s' % jobs
        return renderTable(renderOutput(head, result['Value']))

    return 'There is no job or project selected\n'


@userCreds
def reschedule(args=None):
    project = args.project
    jobs = args.jobid
    user = getProxyUserIfNotWasDefined(args.user)

    infoCollector = InformationCollector()
    statuses = {'Status': ['Failed', 'Stalled', 'Killed']}
    login = [user, args.group]
    # result = infoCollector.getAllJobsInProject(
    #    project, args.date, login, {'Status': ['all']})
    result = infoCollector.getAllJobsInProject(project, args.date, login,
                                               {'Status': statuses['Status']})
    projectsAndJobsToReschedule = result['Value']

    resultOk = {'Value': []}
    if not args.doAll:
        statusesOk = statuses.copy()
        statusesOk['MinorStatus'] = ['Job died during finalization']
        login = [user, args.group]
        resultOk = infoCollector.getAllJobsInProject(project, args.date,
                                                     login, statusesOk)

    jobsToReschedule = []
    for j in projectsAndJobsToReschedule:
        if j not in resultOk['Value']:
            jobsToReschedule.append(j)

    if jobs:
        jobsToReschedule = jobs

    if not jobsToReschedule:
        return 'None jobs to reschedule'

    if not args.force:
        from utils.ui import UI
        result = \
            UI().yes_no_dialog('Do you want to reschedule %s project and %s jobs'
                               % (args.project, jobsToReschedule))
        if not result['OK'] or not result['Value']:
            return ''

    manager = Manager()

    if args.download:
        opt = ''
        if args.project:
            opt = ' -D ' + ' '.join(args.project)
        print('Downloading log files...\n')
        print(manager.downloadJobsOutputOnce(jobsToReschedule, opt))

    result = manager.rescheduleJobs(jobsToReschedule)
    if len(result) != 0:
        data = [['Rescheduled jobs:']]
        for info in result:
            data.append(['job: %s' % info])
        return renderTable(data)

    return 'There is no Jobs or Projects selected\n '


@userCreds
def summary(args=None):
    ctable = ['\033[0m', '\033[37m', '\033[34m', '\033[1m']
    projects = [args.project]
    login = [args.user, args.group]
    statuses = {'Status': [args.status], 'MinorStatus': [args.minorstatus],
                'ApplicationStatus': [args.appstatus]}

    infoCollector = InformationCollector()

    if args.long:
        result = infoCollector.siteSummary(projects, args.date, login,
                                           statuses, args.site)
    else:
        result = infoCollector.siteSummaryFast(args.site)

    if not result['OK']:
        return result['Message']

    value = result['Value']
    jobStates = sorted(value[list(value.keys())[0]].keys())
    sumCounts = [0] * len(jobStates)

    print('%-20s ' % 'Site', end=' ')
    for i in jobStates:
        print('%8s ' % i, end=' ')
    print()

    for site in sorted(value.keys()):
        counts = []
        for count in sorted(value[site].keys()):
            counts.append(value[site][count])

        sumCounts = [a + b for (a, b) in zip(sumCounts, counts)]

        runningIndex = 2
        if args.long:
            runningIndex = 5

        if counts[runningIndex] == 0:
            if args.color:
                print(ctable[args.color], '\r', end=' ')
        elif args.color:
            print(ctable[0], '\r', end=' ')

        print('%-20.20s ' % site, end=' ')
        for i in counts:
            print('%8s ' % i, end=' ')
        print()

    if args.color:
        print(ctable[0], end=' ')

    print('-' * 100)
    print('%-20s ' % 'Total', end=' ')
    for i in sumCounts:
        print('%8s ' % i, end=' ')

    return ''


@userCreds
def submit(args):
    return gbasf2.main(args)


@userCreds
def jobTest(args):
    return gb2_job_test.main(args)


@userCreds
def pilotSummary(args):

    def createRow(site, tables):
        return [
            site,
            tables[site]['Done'],
            tables[site]['Aborted'],
            tables[site]['Running'],
            tables[site]['Scheduled'],
            tables[site]['Ready'],
        ]

    # HM: available only for admin; may be not useful?
    # if args.long:
    #    result = InformationCollector().getPilotCount()
    #    print result['Value'][0]
    #    print result['Value'][1]

    colorTable = ['\033[0m', '\033[37m', '\033[34m', '\033[1m']
    result = InformationCollector().pilotSummary()

    if not result['OK']:
        return result['Message']

    tables = result['Value']
    print('CE                           Done   Aborted   Running Scheduled     Ready')
    for site in sorted(tables.keys()):
        if site == 'Total' or site == 'NotAssigned':
            continue
        if tables[site]['Running'] == 0 and args.color:
            print(colorTable[args.color], end=' ')
        elif args.color:
            print(colorTable[0], end=' ')
        s = '%-24.24s' % site
        s += '%(Done)9d %(Aborted)9d %(Running)9d %(Scheduled)9d %(Ready)9d' \
            % tables[site]
        print(s)

    print('\033[0m', end=' ')
    s = '%-24.24s' % 'Total'
    s += '%(Done)9d %(Aborted)9d %(Running)9d %(Scheduled)9d %(Ready)9d' \
        % tables['Total']
    print('-' * 74)
    print(s)
    return ''


@userCreds
def transformationSummary(args):
    tableData = [[
        'Transformation',
        'TransID',
        'Group',
        'Type',
        'Auto',
        'Status',
        'Done',
        'Comp',
        'Fail',
        'Run',
        'Wait',
        'Total',
        'Submission Time(UTC)',
        'LastUpdate Time(UTC)',
        'Desc',
    ]]

    keys = [
        'TransformationName',
        'TransformationID',
        'TransformationGroup',
        'Type',
        'Automatic',
        'Status',
        'Done',
        'Completed',
        'Failed',
        'Running',
        'Waiting',
        'TotalCreated',
        'CreationDate',
        'LastUpdate',
        'Description',
    ]
    width = 200
    # print args.long
    if args.long <= 1:
        tableData[0].remove('Type')
        keys.remove('Type')
        tableData[0].remove('Desc')
        keys.remove('Description')
        width = 150
    if not args.long:
        tableData[0].remove('Comp')
        keys.remove('Completed')
        tableData[0].remove('LastUpdate Time(UTC)')
        keys.remove('LastUpdate')
        width = 150

    statuses = args.trans_status
    date = args.date
    long = args.long
    result = InformationCollector().transformationSummary(statuses, date, int)

    if not result['OK']:
        return result['Message']

    tables = result['Value']

    for tid in sorted(tables):
        record = [tables[tid][key] for key in keys]
        tableData.append(record)
    return renderTable(tableData, width)


@userCreds
def projectAnalysis(args):
    import re
    _r = \
        re.compile('[^A-Za-z]*([A-Z][a-z]+[A-Z][a-z]+([A-Z][a-z]+)*)[^A-Za-z0-9]*'
                   )

    def deWiki(s):
        sp = s.split(' ')
        ss = ''
        for s in sp:
            res = re.search(_r, s)
            if res is not None:
                s = '!' + s
            ss += s + ' '
        return ss.rstrip()

    def nothing(s):
        return s

    def output(
        format1,
        format2,
        format3,
        format4,
        func,
    ):

        for s in index:
            if s in tstats:
                print(format1 % (func(s), stats[s]))
                for m in sorted(tstats[s].keys()):
                    print(format2 % (func(m), mstats[s][m]))
                    for a in sorted(tstats[s][m].keys()):
                        print(format3 % (func(a), astats[s][m][a]))
                        for t in sorted(tstats[s][m][a].keys()):
                            print(format4 % (func(t), tstats[s][m][a][t]))

    result = InformationCollector().projectAnalysis(args.project, '2013-01-01')
    if 'Value' not in result:
        return result
    (stats, mstats, astats, tstats) = result['Value']

    index = [
        'Done',
        'Completed',
        'Failed',
        'Killed',
        'Deleted',
        'Stalled',
        'Running',
        'Waiting',
    ]

    if not args.twiki:
        print('Project %s summary:' % args.project)
        formats = ['%s (%d)', '  %s (%d)', '    %s (%d)', '       %-15s:%4d']
        output(func=nothing, *formats)
        return ''

    print()
    print('   * *%s*' % args.project)
    formats = ['      * %s (%d)', '         * %s (%d)', '            * %s (%d)', '               * %-15s:%4d']
    output(func=deWiki, *formats)
    return ''


@userCreds
def jobParameters(args=None):
    owner = getProxyUserIfNotWasDefined(args.user)
    group = args.group
    date = args.date
    jobIDs = args.jobid
    ngen = args.Ncycle
    if args.Ncycle:
        ngen = int(args.Ncycle)

    if not jobIDs:
        statuses = {'Status': [args.status],
                    'MinorStatus': [args.minorstatus],
                    'ApplicationStatus': [args.appstatus]}
        jobIDs = InformationCollector().getAllJobsInProject(args.project,
                                                            date, [owner, group], statuses, args.site)['Value']

    if len(jobIDs) == 0:
        print('There is no Job selected\n ')
        return ''

    print('%d jobs are selected.' % len(jobIDs))

    if ngen is None:
        result = Manager().jobParameters(jobIDs)
        return result['Value']

    for jobID in jobIDs:
        res = InformationCollector().getAtticJobParameters(jobID, ngen)

        if not res['OK'] or res['Value'] == {}:
            print('Parameters not found for jobID = %s with nCycle = %d ' \
                % (jobID, ngen))
            continue

        print(res)
        pars = res['Value'][ngen]
        print('jobID:%s nCycle:%d\n' % (jobID, ngen))
        print('{', end=' ')
        for par in pars.keys():
            if not par == 'StandardOutput':
                print(" '%s': '%s'" % (par, pars[par]))
        print('}')

    return ''


@userCreds
def analysis(args=None):
    ctable1 = ['\033[0m', '\033[32m', '\033[31m', '\033[0m\033[4m']
    ctable2 = ['\033[0m', '\033[37m', '\033[34m', '\033[1m']

    infoCollector = InformationCollector()
    result = infoCollector.projectAnalysis(
        None,
        args.date,
        args.user,
        args.group,
        None,
        args.site,
    )

    if not result['OK']:
        return result['Message']

    index = [
        'Done',
        'Completed',
        'Failed',
        'Killed',
        'Deleted',
        'Stalled',
        'Running',
        'Waiting',
    ]

    (stats, mstats, astats, tstats) = result['Value']

    if not args.twiki:
        print('Site %s summary:' % args.site)
        for s in index:
            if s in tstats:
                if args.color:
                    print(ctable1[args.color], end=' ')
                print('%s (%d)' % (s, stats[s]))
                for m in sorted(tstats[s].keys()):
                    if args.color:
                        print(ctable1[0], end=' ')
                    print('  %s (%d)' % (m, mstats[s][m]))
                    for a in sorted(tstats[s][m].keys()):
                        if args.color:
                            print(ctable2[args.color], end=' ')
                        print('    %s (%d)' % (a, astats[s][m][a]))
        if args.color:
            print(ctable2[0], end=' ')

    return ''
