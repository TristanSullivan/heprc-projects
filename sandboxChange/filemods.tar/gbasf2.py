#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import print_function
from BelleDIRAC.gbasf2.lib.auth import userCreds
from BelleDIRAC.gbasf2.lib.gbasf2_params import Params
from BelleDIRAC.gbasf2.lib.job.gbasf2helper import *
from BelleDIRAC.gbasf2.lib.utils.util import natural
import time

@userCreds
def main(clParams, dirac=None):

    import BelleDIRAC.gbasf2.lib.job.storeSandbox as storeSandbox
    if not dirac:
        from DIRAC.Interfaces.API import Dirac
        dirac = Dirac.Dirac()

    pm = Params()
    pm.cliParams = clParams

    gLogger.setLevel(pm.cliParams.getLoglevel())
    gLogger.showHeaders(False)

    # check available BelleDIRAC releases for user job
    ret = checkBelleDIRACRelease(pm)
    if not ret['OK']:
        return ret['Message']
    # Check if basf2 release is enabled for job execution
    ret = checkBasf2Release(pm)
    if not ret['OK']:
        return ret['Message']
    # Verifies that project name is allowed
    ret = checkProject(pm)
    if not ret['OK']:
        return ret['Message']
    # Check Python syntax on steering file
    ret = checkSyntaxError(pm)
    if not ret['OK']:
        return ret['Message']

    pm.userpath = gConfig.getValue('/LocalInstallation/UserPath', '/belle/user/')

    # Resolve the LPNs for input datasets
    ret = resolveInputDS(pm)
    if not ret['OK']:
        return ret['Message']
    if ret['Value'] != 'None':
        pm.input_dspath = ret['Value']
        pm.cliParams.setInputDS(ret['Value'])

    # Fix output dataset path.
    ret = resolveOutputDS(pm)
    if not ret['OK']:
        return ret['Message']
    pm.output_dspath = ret['Value']
    pm.cliParams.setOutputDS(ret['Value'])

    # Treatment of conflicting dataset.
    ret = checkOutputDS(pm)
    if not ret['OK']:
        return ret['Message']
    pm.projectStatus = ret['Value']

    # Resolves sites to avoid for submission.
    ret = resolveBannedSite(pm)
    if not ret['OK']:
        return ret['Message']
    pm.banned_sites = ret['Value']

    # Check if site in client parameters is valid for submission.
    ret = checkSite(pm)
    if not ret['OK']:
        return ret['Message']

    # Verifies that the SE in client parameters is available.
    ret = checkSE(pm)
    if not ret['OK']:
        return ret['Message']

    # Checks the metadata version and returns the latest value if not specified by user
    ret = resolveMetaVersion(pm)
    if not ret['OK']:
        return ret['Message']
    pm.cliParams.setMetaVersion(ret['Value'])

    # FIXME: extract address metadata query

    # Query metadata of input files
    inputFiles = {}
    if pm.input_dspath != []:
        ret = queryMetadata(pm)
        if not ret['OK']:
            return ret['Message']
        inputFiles = ret['Value']
        if not inputFiles:
            print('No files found from input dataset')
            print('Check query or file conditions (perhaps file status is not "good")')
            DIRAC.exit(1)

    # If no input dataset, obtain event number from steering file
    if not inputFiles:
        evnum = find_event_number(pm.cliParams.getSteeringFile())
        if evnum == 0:
            print('Cannot obtain event number from steering file')
        inputFiles[0] = {}
        inputFiles[0]['lfn'] = 'None'
        inputFiles[0]['nEvents'] = evnum

    # Tarball with input files is built
    ret = makeTar(pm)
    if not ret['OK']:
        return ret['Message']
    pm.tarball = ret['Value']

    exitCode = 0          
    pm.nevents = 0
    pm.inputSize = 0
    nFiles = pm.cliParams.getNfiles()
    pm.lfns = [inputFiles[f]['lfn'] for f in sorted(inputFiles, key=natural)]
    pm.totalLfns = len(pm.lfns)

    # If there is more than one file per job (option '-n N'), arrange input files per SE.
    if pm.totalLfns > 1 and nFiles > 1:
        ret = splitInputFilesPerSite(pm)
        if not ret['OK']:
            return ret
        pm.lfns = ret['Value']
    pm.totalJobs = len(pm.lfns)

    # Get the total size and number of events
    # TODO: Make this a method in the gbasf2helper
    hasSize = True
    for result in sorted(inputFiles, key=natural):
        if not 'size' in inputFiles[result]:
            hasSize = False
        else:
            try:
                _size = int(inputFiles[result]['size'])
            except ValueError as ex:
                hasSize = False
        try:
            pm.nevents += int(inputFiles[result]['nEvents'])
        except ValueError as ex:
            print('nEvents is not valid in %s: %s' % (result, inputFiles[result]['nEvents']))
    inputSize = []
    if hasSize:
        sizes = [int(inputFiles[f]['size']) for f in sorted(inputFiles, key=natural)]
        if nFiles > 1:
            sizes = []
            for lfns in pm.lfns:
                sizes.append([int(inputFiles[l]['size']) for l in lfns])
        for jobSize in sizes:
            if isinstance(jobSize, list):
                inputSize.append(sum(jobSize))
            else:
                inputSize.append(jobSize)
        if len(inputSize):
            maxInputSize = max(inputSize)
            pm.inputSize = sum(inputSize)            
            if maxInputSize >= 5*1024*1024*1024:
                print('Maximum input file size exceeds limit (5 GB per job)')
                DIRAC.exit(1)

    # If do_forecast is set as True in the cliparams, get sites able to run the jobs based on input files location.
    if pm.cliParams.getDoForecast():
        ret = getSitesForInputFiles(pm)
        if not ret['OK']:
            return ret
        pm.siteDict = ret['Value']

    # Build a new basf2 steering file, appending gb2 parameters at the end of the file.
    ret = makeSteeringFile(pm)
    if not ret['OK']:
        return ret['Message']
    pm.submit_steering_file = ret['Value']

    # Build the DIRAC Job instances from the parameters.
    ret = makeJobs(pm)
    if not ret['OK']:
        return ret['Message']
    jobsList = ret['Value']

    # Delay between batches of jobs
    timeBetweenBatches = Operations().getValue('GBasf2/SecondsBetweenBatchesInSubmission', 5)

    # Print the job information before the submission
    printJobInfo(pm)
    if pm.cliParams.getLoglevel().lower() == 'debug':
        for j in jobsList:
            gLogger.debug(">>>>>> ABOUT TO PRINT JOBINFO: %s  >>>>>>" % j.workflow )
            j._dumpParameters()
            gLogger.debug(">>>>>> InputSandbox : %s >>>>>>" % j.workflow.parameters )

    # Resolve if scout jobs must be submitted if not specified by user
    if pm.cliParams.getDoScout() is None:
        resolveDoScout(pm)
    try:
        if not pm.cliParams.getDoDryrun():
            if not pm.cliParams.getDoForce() and not pm.cliParams.getBasf2path():
                confirmSubmission()
            scoutID = None
            if pm.cliParams.getDoScout():
                # Submit scout jobs
                nJobs = Operations().getValue('GBasf2/Scouting/nJobs', 100)
                totalscoutjobs = Operations().getValue('GBasf2/Scouting/totalScoutJobs', 10)

                if nJobs < totalscoutjobs:
                    msg = 'Parameter of total scout jobs should be smaller than nJobs.'
                    return msg

                if pm.totalJobs > nJobs:
                    print('Scout jobs will be submitted')
                    ret = copytoScoutJobs(pm, totalscoutjobs)
                    if not ret['OK']:
                        return ret['Message']
                    spm = ret['Value']
                    ret = makeJob(spm)
                    if not ret['OK']:
                        return ret['Message']
                    sj = ret['Value']

                    registerProject(spm)
                    scoutsubresult = dirac.submitJob(sj)
                    if os.path.isfile(spm.submit_steering_file):
                        os.remove(spm.submit_steering_file)

                    if scoutsubresult['OK']:
                        val = eval(str(scoutsubresult['Value']))
                        if not isinstance(val, list) or len(val) < 10:
                            print(('Scout JobID = %s' % scoutsubresult['Value']))
                        else:
                            print('Scout JobID = %s ... %s (%d jobs)' % (val[0],
                                                                         val[len(val) - 1], len(val)))
                        scoutID = str(val[0]) + ':' + str(val[len(val) - 1])
                        for j in jobsList:
                            j.setParameterSequence('ScoutID', [scoutID] * j.numberOfParameters)
                    else:
                        print('ERROR in %s' % str(scoutsubresult['Message']))
                        exitCode = 2

            if exitCode == 0:
                # Initialize the directories for metadata of project and output files
                registerProject(pm)

                # Submit the jobs
                if pm.cliParams.getBasf2path() is None:
                    # Store the jobs submitted in the iterations
                    submittedJobs = []
                    for j in jobsList:
                        j = storeSandbox.storeSandbox(j)
                        subresult = dirac.submitJob(j)
                        if subresult['OK']:
                            val = eval(str(subresult['Value']))
                            if not isinstance(val, list):
                                val = [val]
                            if len(val) < 10:
                                print('JobID = %s' % subresult['Value'])
                            else:
                                print('JobID = %s ... %s (%d jobs)' % (val[0],
                                                                       val[len(val) - 1], len(val)))
                            submittedJobs.extend(val)
                        else:
                            print('ERROR in %s' % str(subresult['Message']))
                            if submittedJobs:
                                print('Project submission failed. Will attempt to kill submitted jobs...')
                                from BelleDIRAC.gbasf2.lib.job.manager import Manager as jobManager
                                manager = jobManager()
                                res = manager.kill(submittedJobs)
                                if res['OK']:
                                    print('JobID = %s ... %s (%d jobs) killed' % (submittedJobs[0],
                                                                                  submittedJobs[len(submittedJobs) - 1], len(submittedJobs)))
                                else:
                                    print("Failed to kill jobs! Please kill jobs by yourself using gb2_job_kill")
                            exitCode = 2
                            break
                        if len(jobsList) > 1:
                            time.sleep(timeBetweenBatches)
                else:
                    for j in jobsList:
                        dirac.submitJob(j, mode='local')
                
                #storeSandbox.cleanupSandboxes()
    finally:
        # clean temporary files
        if os.path.isfile(pm.submit_steering_file):
            os.remove(pm.submit_steering_file)
        if os.path.isfile(pm.tarball):
            os.remove(pm.tarball)


    # print 'to monitor your jobs'
    DIRAC.exit(exitCode)

@userCreds
def registerTransformation(clParams, onlySandbox=False):
# ToDo: separate command line options to simplify user gbasf2

    pm = Params()
    pm.cliParams = clParams

    ret = makeTar(pm)
    if not ret['OK']:
        return ret['Message']
    pm.tarball = ret['Value']
    pm.lfns= ['None']

    ret = makeSteeringFile(pm)
    if not ret['OK']:
        return ret['Message']
    pm.submit_steering_file = ret['Value']

    ret = makeJob(pm)
    if not ret['OK']:
        return ret['Message']

    j = ret['Value']
    ret = submitTransformation(pm, j, onlySandbox)
    return ret

if __name__ == '__main__':
    main()
