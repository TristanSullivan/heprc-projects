#!/usr/bin/env python

import tempfile
from shutil import copy2, rmtree
import StringIO

from BelleDIRAC.Client.controllers.datasetCLController import rmAsync, listDatasets
from BelleDIRAC.Client.gb2_scripts.gb2_ds_rm import getOpt as dsRmgetOpt
from BelleDIRAC.Client.gb2_scripts.gb2_ds_list import getOpt as dsListgetOpt
from BelleDIRAC.Client.helpers.auth import getProxyUserIfNotWasDefined
import BelleDIRAC.gbasf2.lib.ds.manager as dsmanager
from BelleDIRAC.gbasf2.lib.auth import getProxyUser
from random import randrange
from DIRAC import gLogger


def getRandomSE(datamanager):

    se_list = datamanager.getSEs() #returns list of ses
    se_list = [ se for se in se_list if "TMP" in se ]
    gLogger.debug(">>>>>> se_list: %s >>>>>>" % se_list )

    randSE = se_list[randrange(len(se_list))]
    while "Pisa" in randSE or "KEK-DEV" in randSE or "KEK-TMP-SE" in randSE or "Australia" in randSE or "Torino" in randSE or "NTUCC" in randSE:
        randSE = se_list[randrange(len(se_list))]

    return randSE

def uploadSandbox(sbList,owner,retry=True):
    import time
    from subprocess import Popen, PIPE

    #make tempdir
    #put files in tempdir
    #use gb2_ds_generate to uploadsandbox
    #    need to choose SE
    gLogger.debug(">>>> Upload Sandbox! >>>>>> ")
    man=dsmanager.Manager()
    SE = getRandomSE(man)
    gLogger.debug(">>>> Got random SE: %s" % SE )

    sandboxName = "inputSandbox-"+str(time.time())

    gLogger.debug(">>>>>>Making tempdir, copying files in>>>>>>")
    tdir = tempfile.mkdtemp()
    user = getProxyUserIfNotWasDefined(owner)
    try:
        for file in sbList:
            copy2(file,tdir)
        gLogger.debug(">>>>>>UPLOADING DATASET>>>>>>")
        cmd=["gb2_ds_generate", "-u", user, "-d", SE, "-i", tdir, sandboxName]
        p = Popen(cmd,stdout=PIPE,stderr=PIPE)
        stdout,stderr = p.communicate()
        ret = p.returncode
        #ret = man.generate(sandboxName,user,SE,tdir)
        if ret !=0:
            #try again
            gLogger.info("Failed to upload Sandbox, trying again. %s" % stderr )
            p2 = Popen(cmd,stdout=PIPE,stderr=PIPE)
            stdout2,stderr2 = p2.communicate()
            ret2 = p.returncode
            #ret2 = man.generate(sandboxName,user,SE,tdir)
            if ret2 != 0:
                #try new SE
                
                if retry:
                    gLogger.info("Failed again to upload, try new SE. %s" % stderr2 )
                    rmtree(tdir)
                    uploadSandbox(sbList,owner,retry=False)
                else:
                    gLogger.info("Failed yet again to upload, exiting. Code: %s, Message: %s" % (ret2,stderr2 ))
                    raise Exception("Unable to upload sandbox after trying 2 SEs")
    except:
        raise
    finally:
        try:
            rmtree(tdir)
        except OSError:
            pass

    return sandboxName



def cleanupSandboxes(owner=None):
    #list sandbox datasets in /belle/user/owner/
    if owner == None:
        owner=getProxyUser()
    
    args=dsListgetOpt()
    lsargs=args.parse_args(['-u',owner])
    res = listDatasets(lsargs)
    alldatasets = res.split('\n')
    for dataset in alldatasets:
        if "inputSandbox-" in dataset:
            deleteUploaded(owner,dataset)
    #delete old ones
    return None

def deleteUploaded(owner,dsName):
    args=dsRmgetOpt()
    rmargs = args.parse_args(['-f','-u',owner,dsName])
    rmAsync(rmargs)

    return

def storeSandbox(job):
    gLogger.debug(">>>>>> Entered Function >>>>>>")
    
    #get job owner name
    uname = getProxyUser()
    gLogger.debug(">>>>>> Got owner: %s" % uname)
    gLogger.debug("JOB: %s " % job._toJDL(jobDescriptionObject=StringIO.StringIO(job._toXML)))

    cleanupSandboxes(owner=uname)

    #get sandbox string and split into individual files
    sstr = [ par.getValue() for par in job.workflow.parameters if par.getName() == "InputSandbox" ][0]
    sandList = sstr.split(';')

    gLogger.debug(">>>>>> Got sandbox file list: %s" % sandList)
    #get add to sandbox values, add to list
    addSandList = job.addToInputSandbox

    sandList += addSandList
    gLogger.debug(">>>>>> Added to sandList now complete: %s " % sandList)
    
    
    sbName = uploadSandbox(sandList,uname)
    gLogger.debug(">>>>>> Finished Uploading >>>>>>")

    newInputStr = ""
    newPathPrefix = "LFN:/belle/user/"+str(uname)+"/"+str(sbName)+"/"
    for file in sandList:
        newpath = newPathPrefix+file.split('/')[-1]
        newInputStr+= newpath+";"

    gLogger.debug(">>>>>> Finished changing Sandbox string, modifying job >>>>>>")

    job.workflow.parameters.setValue("InputSandbox",newInputStr,vtype="JDL")
    job.addToInputSandbox=[]

    return job